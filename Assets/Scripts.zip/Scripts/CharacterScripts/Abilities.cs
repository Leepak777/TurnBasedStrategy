using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Abilities : MonoBehaviour
{
    TileManager tileM;
    ParticleSystem ps;
    void Start()
    {
        tileM = GameObject.Find("Tilemanager").GetComponent<TileManager>();
        if(gameObject.GetComponentInChildren<ParticleSystem>() != null){
            ps = gameObject.GetComponent<ParticleSystem>();
        }
    }

    void LeadersshipAura(){
        foreach(Node n in tileM.GetTilesInArea(gameObject.GetComponent<Teleport>().getOrigin(), ps.shape.radius/16)){
            if(n.occupant != null && n.occupant.tag != gameObject.tag){
                Debug.Log("pog");
            }
        }
    }

    

    // Update is called once per frame
    void Update()
    {
        
    }
}
